<?php

require("config.php");
mysqli_query($koneksi, "DELETE FROM tdok_jadwal");

?>
