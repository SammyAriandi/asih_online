vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Mar 2018 10:32:08 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|25 Mar 2018 10:32:08 -0000
vti_cacheddtm:TX|25 Mar 2018 10:32:08 -0000
vti_filesize:IR|134
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_backlinkinfo:VX|
