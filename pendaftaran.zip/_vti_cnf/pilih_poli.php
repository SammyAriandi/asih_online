vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Apr 2018 14:29:59 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|18 Apr 2018 07:37:02 -0000
vti_backlinkinfo:VX|pilih_dokter.php
vti_nexttolasttimemodified:TW|27 Apr 2018 10:27:40 -0000
vti_title:SR|Pendaftaran Online
vti_cacheddtm:TX|27 Apr 2018 10:27:40 -0000
vti_filesize:IR|2260
vti_cachedtitle:SR|Pendaftaran Online
vti_cachedbodystyle:SR|<body bgcolor="#C0C0C0">
vti_cachedlinkinfo:VX|H|images/icon.png S|images/logo.png S|images/bg_login.png S|images/bg_login.png S|images/bg_login.png H|login.php S|images/home.png
vti_cachedsvcrellinks:VX|FHUS|images/icon.png FSUS|images/logo.png FSUS|images/bg_login.png FSUS|images/bg_login.png FSUS|images/bg_login.png FHUS|login.php FSUS|images/home.png
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us viewport width=device-width;\\ initial-scale=0.9;\\ maximum-scale=0.9;
vti_charset:SR|windows-1252
vti_language:SR|en-us
