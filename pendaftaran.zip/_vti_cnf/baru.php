vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Apr 2018 07:30:40 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|25 Mar 2018 14:27:21 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|25 Mar 2018 14:27:21 -0000
vti_cacheddtm:TX|21 Apr 2018 07:30:40 -0000
vti_filesize:IR|1345
vti_cachedbodystyle:SR|<body bgcolor="#C0C0C0" style="text-align: center">
vti_cachedlinkinfo:VX|S|images/logo.png S|images/bg_login.png H|login.php
vti_cachedsvcrellinks:VX|FSUS|images/logo.png FSUS|images/bg_login.png FHUS|login.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us viewport width=device-width;\\ initial-scale=0.9;\\ maximum-scale=0.9;
vti_charset:SR|windows-1252
vti_language:SR|en-us
