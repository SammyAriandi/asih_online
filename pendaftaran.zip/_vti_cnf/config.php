vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Apr 2018 01:21:45 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|25 Mar 2018 10:12:29 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|27 Apr 2018 01:21:44 -0000
vti_cacheddtm:TX|27 Apr 2018 01:21:45 -0000
vti_filesize:IR|416
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
