vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 May 2018 15:21:44 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|18 Apr 2018 07:36:11 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|20 May 2018 15:21:37 -0000
vti_title:SR|Pendaftaran Online
vti_cacheddtm:TX|20 May 2018 15:21:44 -0000
vti_filesize:IR|3614
vti_cachedtitle:SR|Pendaftaran Online
vti_cachedbodystyle:SR|<body bgcolor="#C0C0C0">
vti_cachedlinkinfo:VX|H|images/icon.png S|images/logo.png A|insert_daftar.php H|pilih_jam.php S|images/back.png H|login.php S|images/home.png
vti_cachedsvcrellinks:VX|FHUS|images/icon.png FSUS|images/logo.png FAUS|insert_daftar.php FHUS|pilih_jam.php FSUS|images/back.png FHUS|login.php FSUS|images/home.png
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us viewport width=device-width;\\ initial-scale=0.9;\\ maximum-scale=0.9;
vti_charset:SR|windows-1252
vti_language:SR|en-us
