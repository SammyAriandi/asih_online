vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 May 2018 02:46:23 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|03 Apr 2018 13:15:34 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|02 May 2018 02:44:34 -0000
vti_cacheddtm:TX|02 May 2018 02:44:34 -0000
vti_filesize:IR|353
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
