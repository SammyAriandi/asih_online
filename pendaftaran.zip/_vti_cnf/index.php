vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Apr 2018 08:49:20 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|Infinity-PC\\Infinity
vti_modifiedby:SR|Infinity-PC\\Infinity
vti_timecreated:TR|18 Apr 2018 07:53:06 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|18 Apr 2018 08:48:22 -0000
vti_cacheddtm:TX|18 Apr 2018 08:49:20 -0000
vti_filesize:IR|2195
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
